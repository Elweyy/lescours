# ft_ls

ls clone

```
make
```

usage: ft_ls [-1Rlart] [file folder ...]
