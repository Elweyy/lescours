/**
 * classe charg�e d'�valuer une expression postfix�e
 */
public class Postfixe {

	/**
	 * 
	 * permet d'�valuer une expression
	 * 
	 * @param valeurs
	 *            l'expression sous la forme d'un tableau de String
	 * @return valeur de l'expression
	 */
	public int evaluer(String[] valeurs) {
		// TODO a completer
	}

	/**
	 * constructeur vide ne fait rien juste pour lancer la m�thode
	 */
	public Postfixe() {

	}

}