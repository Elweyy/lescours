/**
 * classe de test pour classe ListeChainee
 * @author vthomas
 *
 */
public class TestListeChainee {

	// TODO tests � ecrire a partir de TestListeContigue
	
	/**
	 * lancement des tests
	 */
	public static void main(String args[])
	{
		if ((args.length==1)&&(args[0].equals("-text")))
			Lanceur.lanceSansInterface(new TestListeChainee());
		else
			Lanceur.lanceAvecInterface(new TestListeChainee());
	}

}
