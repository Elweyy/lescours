import java.util.*;

/**
 * classe qui permet de modeliser un nombre de connexions
 * 
 */
public class Logs {
	/**
	 * attributs tableau de nombre de connexions
	 */
	private int[] connexions;

	/**
	 * attributs, nombre min, max et moyenne du tableau nbrConnexions
	 */
	private int min, max;
	private double moyenne;

	/**
	 * constructeur ou tous les nombres de connexions mensuelles sont
	 * supposes nuls
	 * 
	 * @param n
	 *            nombre de mois d'etude (au moins 1)
	 */
	public Logs(int n) {
		// TODO a completer
	}

	/**
	 * methoed qui met a jour les attributs min max et moyenne
	 */
	private void calculMinMaxMoy() {
		// TODO a completer
	}

	/**
	 * methode de saisie des releves de connexions
	 */
	public void saisirConnexions() {
		// TODO a completer
	}

	/**
	 * pour l'affichage
	 * 
	 * @return chaine de caracteres representant le releve de
	 *         connexions
	 */
	public String toString() {
		String res = "";
		// TODO a completer
		return (res);
	}

	/**
	 * test de nbconnexions
	 * 
	 * @param args
	 *            inutile
	 */
	public static void main(String[] args) {
		Logs nc = new Logs(8);
		nc.saisirConnexions();
		System.out.println(nc);
		nc.corrigerConnexions(2, new int[] { 54, 68, 687 });
		nc.inverserConnexions();
		System.out.println(nc);
		nc.entrerNouveauReleve(7653);
		nc.trierDecroissantConnexions();
		System.out.println(nc);
	}

	/**
	 * permet de corriger des elements successifs du tableau de
	 * nombres de connexions mensuelles
	 * 
	 * @param mois_debut
	 *            indice de la premiere valeur a modifier
	 * @param tab
	 *            nouvelles valeurs
	 */
	public void corrigerConnexions(int mois_debut, int[] tab) {
		// TODO a completer
	}

	/**
	 * permet d'inverser l'ordre des valeurs stockees dans le tableau
	 * de nombres de connexions mensuelles
	 */
	public void inverserConnexions() {
		// TODO a completer
	}

	

	/**
	 * permet de rentrer une nouvelle valeur (le nombre de connexions
	 * du dernier mois ecoule) dans le tableau, et met a jour le
	 * nombre minimum, maximum et moyen de connexions
	 * <p>
	 * la case i contient toujours le nombre de connexions mensuelles
	 * enregistre i mois auparavant
	 * 
	 * @param nv
	 *            nouvelle valeur
	 */
	public void entrerNouveauReleve(int nv) {
		// TODO a completer
	}

	/**
	 * constructeur a partir d'un tableau a 2 dimensions de taille n x
	 * 12 dont
	 * la case {[i,j]} correspond au j-ieme mois de l'annee 2013-i
	 * 
	 * @param tab2D
	 *            tableau a 2 dimensions
	 */
	public Logs(int[][] tab2D) {
		// TODO a completer
	}

	/**
	 * tri decroissant par selection
	 */
	public void trierDecroissantConnexions() {
		// TODO a completer
	}

	/**
	 * getter
	 * 
	 * @return le tableau de nombre de connexions
	 */
	public int[] getNbrConnexions() {
		return this.connexions;
	}

	/**
	 * getter
	 * 
	 * @return le min
	 */
	public int getMin() {
		return this.min;
	}

	/**
	 * getter
	 * 
	 * @return le max
	 */
	public int getMax() {
		return this.max;
	}

	/**
	 * getter
	 * 
	 * @return la moyenne
	 */
	public double getMoyenne() {
		return this.moyenne;
	}

	/**	
	 * faire un tri decroissant par une methode a bulle
	 */
	public void trierDecroissantBulle() {
		// TODO a completer
	}
}