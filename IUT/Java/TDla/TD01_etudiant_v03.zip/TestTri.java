/**
 * classe de test pour classe Listecontigue
 * @author vthomas
 *
 */
public class TestTri {
	
	
	/**
	 * tri d'une liste normale
	 */
	public void test_1_TriNormal()
	{
		//TODO à écrire
	}
	
	/**
	 * tri d'une liste avec un element
	 */
	public void test_2_TriUnique()
	{
		//TODO à écrire
	}
	
	
	/**
	 * tri d'une liste vide
	 */
	public void test_3_TriVide()
	{
		//TODO à écrire
	}
	
	/**
	 * tri d'une liste trié
	 */
	public void test_4_TriTrie()
	{
		//TODO à écrire
	}
	
	
	/**
	 * lancement des tests
	 */
	public static void main(String args[])
	{
		if ((args.length==1)&&(args[0].equals("-text")))
			Lanceur.lanceSansInterface(new TestTri());
		else
			Lanceur.lanceAvecInterface(new TestTri());
	}

}
