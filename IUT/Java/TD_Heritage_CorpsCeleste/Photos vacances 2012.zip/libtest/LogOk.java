package libtest;

/**
 * gere un log qui s'est bien d�roul� 
 *
 */
public class LogOk extends Log{

	public LogOk(String nom) {
		this.type="Ok";
		this.nomMethode=nom;
	}

	
}
